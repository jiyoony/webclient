import React from 'react';
import Search from "./components/Search" 

function App(){
  return (
  <Search> </Search>
  // <TodoTemplate>
  //   <Search/>
  // </TodoTemplate>
  );
}

export default App;
