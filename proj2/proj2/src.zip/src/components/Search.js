import React from 'react';
import Movie from './Movie';
import { MdAdd } from 'react-icons/md';
import "./Search.scss";
import {naverMoviesApi} from '../api';
import TodoTemplate from './TodoTemplate';
import Hell from './Hell';
import { render } from 'react-dom';

class Search extends React.Component {
  state = {
    isLoading: false,
    movies: [],
    value: "",
    name: "영화 검색"
  };

  getSearchMovie = async () => {
    console.log('search Movie');
    const search = this.state.value;

    try {
      if (search === "") {
        this.setState({movies: [], isLoading: false})
      } else {
        this.setState({movies: [], isLoading: true})
        const {data: {
            items
          }} = await naverMoviesApi.search(search);
        //alert("(Loading 메시지 확인중...)");
        this.setState({movies: items, isLoading: false});
      }
    } catch (error) {
      console.log(error);
    }
  };

  componentDidMount() {
    this.getSearchMovie();
  };

  handleChange = (e : any) => {
    this.setState({value: e.target.value});
  };

  handleSubmit = (e : any) => {
    e.preventDefault();
    this.getSearchMovie();
   
  };

  render() {
    const {movies, isLoading, name} = this.state;
  
 
    return (<section className="container">
      {
        isLoading
          ? (<div className="loader">
            <span className="loader__text">({this.state.name}) Loading... {this.state.value}</span>
          </div>)
          : (<form onSubmit={this.handleSubmit}>
            <TodoTemplate>
              <form className="input_div">
                <input className="input_search" type="text" value={this.state.value} onChange={this.handleChange} placeholder="영화 이름을 입력하세요."/>
                <button type="submit"> <MdAdd /> </button>
              </form>
              <Hell movies={movies}/>
              </TodoTemplate>
          </form>)
      }
    </section>);
  }
}

export default Search;



