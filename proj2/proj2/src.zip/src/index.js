import React from 'react';
import ReactDOM from 'react-dom';

// import Search from "./old_com/Search" 
// ReactDOM.render(<Search />, document.getElementById('root'));

import App from './App';
ReactDOM.render(<App />, document.getElementById('root'));